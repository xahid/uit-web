# mau Gallery

A simple images gallery made with jQuery and bootstrap4

## Notice: This package will soon be deprecated in favour of a next, improved version. Use with caution
